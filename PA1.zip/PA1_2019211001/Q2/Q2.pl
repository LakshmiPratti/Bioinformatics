#!/usr/bin/perl -w

################# REVERSE, COMPLEMENT, REVERSE COMPLEMENT and mRNA #######################

use strict;
use warnings;    

#Input file name from user

print "Type the desired FASTA formatted filename:";

my $file_name = <STDIN>;
   chomp $file_name;

# Declare and initialize variables
my @file_data = (  );
my $dna = '';
my $compdna = '';
my $revdna = '';
my $revcomdna = '';
my $mRNA = '';

# Read in the contents of the file obtained from the user
@file_data = get_file_data($file_name);

# Extract the sequence data from the contents of the file obtained from the user
$dna = extract_sequence_from_fasta_data(@file_data);

# Reversing the dna sequence
$revdna = rev($dna);

# Complement of dna sequence
$compdna = comp($dna);

# Reverse complement of dna sequence
$revcomdna = revcom($dna);

# mRNA of the dna sequence
$mRNA = mrna($dna);

print "Reverse, Complement, Reverse Complement and mRNA of the given sequence is stored in Q2_output.txt\n";

#Redirecting output into file Q2_output.txt
unless (open (STDOUT, ">Q2_output.txt")) { 
 print STDERR "Cannot open file \"Q2_output.txt\"\n\n";
        exit;
}

print "Original Sequence\n";

print_sequence ($dna,80);

print "\nReverse\n";

print_sequence ($revdna,80);

print "\nComplementary\n";

print_sequence ($compdna,80);

print "\nReverse complement\n";

print_sequence ($revcomdna,80);

print "\nmRNA\n";

print_sequence ($mRNA,80);

close(STDOUT);

exit;



###################################################################
########################## SUBROUTINES ############################
###################################################################


# get_file_data
# A subroutine to get data from a file given its filename

sub get_file_data {

    my($filename) = @_;

    # Initialize variables
    my @filedata = (  );

    unless( open(GET_FILE_DATA, $filename) ) {
        print STDERR "Cannot open file \"$filename\"\n\n";
        exit;
    }

    @filedata = <GET_FILE_DATA>;

    close GET_FILE_DATA;

    return @filedata;
}


# extract_sequence_from_fasta_data
# A subroutine to extract FASTA sequence data from an array

sub extract_sequence_from_fasta_data {

    my(@fasta_file_data) = @_;

    # Declare and initialize variables
    my $sequence = '';

    foreach my $line (@fasta_file_data) {

        # discard blank line
        if ($line =~ /^\s*$/) {
            next;

        # discard comment line
        } elsif($line =~ /^\s*#/) {
            next;

        # discard fasta header line
        } elsif($line =~ /^>/) {
            next;

        # keep line, add to sequence string
        } else {
            $sequence .= $line;
        }
    }

    # remove non-sequence data (in this case, whitespace) from $sequence string
    $sequence =~ s/\s//g;

    return $sequence;
}

# print_sequence
# A subroutine to format and print sequence data 

sub print_sequence {

    my($sequence, $length) = @_;

    # Print sequence in lines of $length
    for ( my $pos = 0 ; $pos < length($sequence) ; $pos += $length ) {
        print substr($sequence, $pos, $length), "\n";
    }
}

# comp
# A subroutine to compute complement of given DNA sequence

sub comp{

    my($dna) = @_;

    my $comp = $dna;

    # complement the sequence, dealing with upper and lower case
    # A->T, T->A, C->G, G->C
    $comp =~ tr/ACGTacgt/TGCAtgca/;
    
    return $comp;
}

# rev
# A subroutine to compute reverse of DNA sequence

sub rev {
    
    my($dna) = @_;

    my $rev = reverse $dna;
    
    return $rev;
}

# revcom 
# A subroutine to compute the reverse complement of DNA sequence

sub revcom {

    my($dna) = @_;

    # First reverse the sequence
    my $revcom = reverse $dna;

    # Next, complement the sequence, dealing with upper and lower case
    # A->T, T->A, C->G, G->C
    $revcom =~ tr/ACGTacgt/TGCAtgca/;

    return $revcom;
}

# mrna
# A subroutine to transcribe DNA to mRNA

sub mrna{

    my($dna) = @_;

    my $rna = $dna;
    
    $rna =~ s/T/U/g;
     
    return $rna;
}


