#!/usr/bin/perl 

################# Given a GenBank file can extract the feature table #######################

use strict;
use warnings;

#Input file name from user

print "Type the desired GenBank filename:";

my $file_name = <STDIN>;
   chomp $file_name;

# Declare and initialize variables

my $datafile = '';
my $record = '';
my $annotation = '';
my $dna = '';
my %fields = ( );

# Reading data from the file obtained from the user
$datafile = open_file($file_name);

# Extracting the GenBank record containing annotation and dna
$record = extract_record($datafile);

# Seperating annotation and dna from the extracted GenBank record
($annotation, $dna) = seperate_anno_dna($record);

# Parsing annotation into hash variable to make dictionary with,
#			key = Field names
#			values = Field
%fields = parse_anno($annotation);
print("Features table for $file_name is stored in features_$file_name.txt\n");

#Redirecting output into file $file_name.fasta
unless (open (STDOUT, ">features_$file_name.txt")) { 
 print STDERR "Cannot open file \"features_$file_name.txt\"\n\n";
        exit;
}

print $fields{'FEATURES'};

close(STDOUT);

exit;





###################################################################
##################### SUBROUTINES #################################
###################################################################

# open_file
# A subroutine to get data from the file given its file name

sub open_file {
	
	my ($filename) = @_;
	my $datafile;

	unless(open($datafile, $filename)) {
		print "Cannot open file $filename\n";
		exit;
	}
	return $datafile;
}


# extract_record
# A subroutine to extract the GenBank record containing annotation and dna

sub extract_record {

	my ($datafile) = @_;

	# declaring variable
	my $record = '';
	my ($save_input_separator) = $/;

	# Set input separator to "//\n" and read in a record to a scalar
	$/ = "//\n";
	
	$record = <$datafile>;

	$/ = ($save_input_separator);
	
	return $record;
}


# seperate_anno_dna
# A subroutine to seperate annotation and dna from the extracted GenBank record

sub seperate_anno_dna {

	my ($record) = @_;

	# declaring variables
	my ($annotation) = '';
	my ($dna) = '';
	
	# Seperation of annotation from the sequence data
	($annotation, $dna) = ($record =~ /^(LOCUS.*ORIGIN\s*\n)(.*)\/\/\n/s);

	# Removing whitespaces or / characters in the sequence 
	($dna) =~ s/[\s0-9]//g;

	return ($annotation, $dna);
}

# parse_anno
# A subroutine to parse annotation and returning hash with 
#           keys: Field names
#	    values: Fields

sub parse_anno {

	my($annotation) = @_;
	my(%parse_hash) = ( );

	while ($annotation =~ /^[A-Z].*\n(^\s.*\n)*/gm ) {
        my $value = $&;
        (my $key = $value) =~ s/^([A-Z]+).*/$1/s;
        $parse_hash{$key} = $value;
    }

    return %parse_hash;
}

 
