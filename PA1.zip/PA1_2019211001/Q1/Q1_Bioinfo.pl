#!/usr/bin/perl 

####### Given a FASTA file, can find any restriction enzymes recognition site locations ##########

use strict;
use warnings;    

#Input file name from user

print "Type the desired filename (FASTA FORMAT):";

my $file_name = <STDIN>;
   chomp $file_name;

# Declare and initialize variables
my %rebase_hash = (  );
my @file_data = (  );
my $query = '';
my $dna = '';
my $recognition_site = '';
my $regexp = '';
my @locations = (  );

# Reads the input file obtained from the user 
@file_data = get_file_data($file_name);

# Extract the DNA sequence data from the contents of the file obtained from user
$dna = extract_sequence_from_fasta_data(@file_data);

# Get the REBASE data into a hash, from file "rebase.bionet"
### 'rebase.bionet' is a file containing all available restriction enzymes with their corresponding restriction sites###
# Using parseREBASE, creating a dictionary containing all RE and their recognition sites 

%rebase_hash = parseREBASE('rebase.bionet');

# Prompt user for restriction enzyme names, create restriction map
do {
    print "Type Restriction enzyme name (eg: as BamHI not bamhi ) (or type quit)?: ";
    
    $query = <STDIN>;

    chomp $query;

    # Exit if empty query
    if ($query =~ /^\s*$/ ) {

        exit;
    }

    # Perform the search in the DNA sequence
    if ( exists $rebase_hash{$query} ) {

        ($recognition_site, $regexp) = split ( " ", $rebase_hash{$query});

        # Create the restriction map
        @locations = match_positions($regexp, $dna);

        # Report the restriction map to the user
        if (@locations) {
            print "Searching for $query $recognition_site $regexp\n";
            print "A restriction site for $query at locations:\n";
            print join(" ", @locations), "\n";
        } else {
            print "A restriction enzyme $query is not in the DNA:\n";
        }
    }
    print "\n";
} until ( $query =~ /quit/ );

exit;



###################################################################################
############################ SUBROUTINES ##########################################
###################################################################################



# get_file_data
# A subroutine to get data from a file given its filename

sub get_file_data {

    my($filename) = @_;

    # Initialize variables
    my @filedata = (  );

    unless( open(GET_FILE_DATA, $filename) ) {
        print STDERR "Cannot open file \"$filename\"\n\n";
        exit;
    }

    @filedata = <GET_FILE_DATA>;

    close GET_FILE_DATA;

    return @filedata;
}


# extract_sequence_from_fasta_data
# A subroutine to extract FASTA sequence data from an array

sub extract_sequence_from_fasta_data {

    my(@fasta_file_data) = @_;

    # Declare and initialize variables
    my $sequence = '';

    foreach my $line (@fasta_file_data) {

        # discard blank line
        if ($line =~ /^\s*$/) {
            next;

        # discard comment line
        } elsif($line =~ /^\s*#/) {
            next;

        # discard fasta header line
        } elsif($line =~ /^>/) {
            next;

        # keep line, add to sequence string
        } else {
            $sequence .= $line;
        }
    }

    # remove non-sequence data (in this case, whitespace) from $sequence string
    $sequence =~ s/\s//g;

    return $sequence;
}


#IUB_to_regexp
# A subroutine that, given a sequence with IUB ambiguity codes,
# outputs a translation with IUB codes changed to regular expressions
#IUB ambiguity codes
# R = G or A
# Y = C or T
# M = A or C
# K = G or T
# S = G or C
# W = A or T
# B = not A (C or G or T)
# D = not C (A or G or T)
# H = not G (A or C or T)
# V = not T (A or C or G)
# N = A or C or G or T 
# And also removes the ^(caret) symbol from the sequence as it describes the site,
# at which the cut takes place. This makes the final output as regular expressions

#IUB_to_regexp
# A subroutine that, given a sequence with IUB ambiguity codes,
# outputs a translation with IUB codes changed to regular expressions
#IUB ambiguity codes
# R = G or A
# Y = C or T
# M = A or C
# K = G or T
# S = G or C
# W = A or T
# B = not A (C or G or T)
# D = not C (A or G or T)
# H = not G (A or C or T)
# V = not T (A or C or G)
# N = A or C or G or T 
# And also removes the ^(caret) symbol from the sequence as it describes the site,
# at which the cut takes place. This makes the final output as regular expressions

sub IUB_to_regexp {

    my ($iub) = @_;

    my $regular_expression = '';

    my %iub2character_class = (
    
        A => 'A',
        C => 'C',
        G => 'G',
        T => 'T',
        R => '[GA]',
        Y => '[CT]',
        M => '[AC]',
        K => '[GT]',
        S => '[GC]',
        W => '[AT]',
        B => '[CGT]',
        D => '[AGT]',
        H => '[ACT]',
        V => '[ACG]',
        N => '[ACGT]',
    );

    # Remove the ^ signs from the recognition sites
    ($iub) =~ s/\^//g;

    # Translate each character in the iub sequence
    for ( my $i = 0 ; $i < length($iub) ; ++$i ) {
        $regular_expression
          .= $iub2character_class{substr($iub, $i, 1)};
    }

    return $regular_expression;
}


# parseREBASE-Parse REBASE bionet file
# A subroutine to return a hash where
#    key   = restriction enzyme name
#    value = whitespace-separated recognition site and regular expression
# Basically we are creating a dictionary out of restriction enzymes and restriction sites
# It helps on the long run to search for the restriction sites for a given restriction enzyme

sub parseREBASE {

    my($rebasefile) = @_;
  
    # Declare variables
    my @rebasefile = (  );
    my %rebase_hash = (  );
    my $name;
    my $site;
    my $regexp;

    # Read in the REBASE file
    my @rebase_filehandle = get_file_data($rebasefile);

    foreach(@rebase_filehandle) {

        # Discard blank lines
        /^\s*$/ and next;
    
        # Split the two (or three if includes parenthesized name) fields
        my @fields = split( " ", $_);

        # Get and store the name and the recognition site

        # Remove parenthesized names by not saving the middle field, if any,
        # just the first and last
        $name = shift @fields;

        $site = pop @fields;

        # Translate the recognition sites to regular expressions
        $regexp = IUB_to_regexp($site);

        # Store the data into the hash
        $rebase_hash{$name} = "$site $regexp";
    }
  
    # Return the hash containing the reformatted REBASE data
    return %rebase_hash;
}

# match_positions

# A subroutine for finding locations of a match of a regular expression in a string and,
# returns an array of positions where the regular expression appears in the string.


sub match_positions {

    my($regexp, $sequence) = @_;

    # Declare variables
    my @positions = (  );
   
    # Determine positions of regular expression matches
    while ( $sequence =~ /$regexp/ig ) {
         push ( @positions, pos($sequence) - length($&) + 1);
    }

    return @positions;
}


