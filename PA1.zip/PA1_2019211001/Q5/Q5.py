#! bin/usr/python

import sys

def GC_content(gene):   #Defining a function

    total = len(gene)           #return the length of gene
    count = 0
    for i in gene:
        if i == 'g' or i == 'c' or i == 'G' or i == 'C':
            count += 1
    return float(count)/float(total)


def diveation_from_AT_GC(gene):

    a = max(gene.count('a'), gene.count('A'))
    t = max(gene.count('t'), gene.count('T'))
    g = max(gene.count('g'), gene.count('G'))
    c = max(gene.count('c'), gene.count('C'))

    return float(float(a-t)/float(a+t)), float(float(g-c)/float(g+c))


file_name = sys.argv[1]

fp = open(file_name, 'r')
data = fp.read().decode("utf-8-sig").encode("utf-8")


gene_list = data.split('\n')
gene = ''

for i in gene_list[1:]:
    if i != '' :
        gene += i

# print gene
window_len = 50000
gene = list(gene)


start = 0
end = window_len
i=0
count = 1

while i < len(gene) :
    print "GC content : ", GC_content(gene[start: end])
    dev_at, dev_gc = diveation_from_AT_GC(gene[start:end])
    print "Deviation from AT : ", dev_at
    print "Deviation from GC : ", dev_gc
    print '\n'
    start += window_len
    end = min(len(gene), start + window_len)
    i += window_len
    count += 1
