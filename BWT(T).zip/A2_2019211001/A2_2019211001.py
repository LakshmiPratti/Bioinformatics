#! bin/usr/python3

#Created by: Lakshmi Deepita Pratti
#Roll no: 2019211001

#-------------INPUT A STRING------------#

new_str = input("Enter a string: ")
list_1 = []

#-----------ROTATION OF STRING----------#
len_str = len(new_str)
for s in range(0, len_str):
	new_str = new_str[-1] + new_str[:-1]
	list_1 += [new_str]
print("Rotated list of strings: ")
print (list_1) 


#------------SORTING OF ROTATED STRING-------#
sorted_list2 = sorted(list_1)
print("Sorted list of strings: ")
print (sorted_list2)

k = ""
for s in sorted_list2:
	k = k + s[-1]

print("BWT(T) is: ")
print (k)

