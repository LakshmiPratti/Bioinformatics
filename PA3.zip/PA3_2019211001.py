#residue shuffling
import random
sequence=input("enter your sequence: ") 
k="".join(random.sample(sequence,len(sequence)))
print("Residue shuffling is: ", k)

#segment shuffling
segment=list(sequence)
segment_part=segment[3:9]
m=random.sample(segment_part, len(segment_part))
segment_shuffle= segment[0:3]+ m + segment[9:]
string="".join(segment_shuffle)
print("segment shuffling is: ",string)
